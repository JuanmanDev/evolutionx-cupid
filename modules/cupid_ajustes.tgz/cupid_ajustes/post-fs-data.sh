#!/system/bin/sh
# El init del ramdisk esta parcheado por KernelSU y activa el modo depurable de
# AOSP, que fija estas propiedades antes de que se lea build.prop. Como las ro.*
# son inmutables una vez fijadas, hay que volver a ponerlas aqui.
RESETPROP=/data/adb/ksu/bin/resetprop
[ -x "$RESETPROP" ] || exit 0
"$RESETPROP" ro.debuggable 0
"$RESETPROP" ro.force.debuggable 0
